import gma

gma = gma.GMATV()

parsed_gma = gma.parseTVShow()

getshow_gma = gma.getTVShow(parsed_gma)
